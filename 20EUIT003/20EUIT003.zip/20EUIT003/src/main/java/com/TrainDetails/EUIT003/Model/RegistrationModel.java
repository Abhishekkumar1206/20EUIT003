package com.TrainDetails.EUIT003.Model;

public class RegistrationModel {

    private String CompanyName;
    private String OwnerName;
    private String Rollno;
    private String ownerEmail;
    private String accessCode;
}
