package com.TrainDetails.EUIT003.Controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class Registration {


}
